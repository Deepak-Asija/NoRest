﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using NoRest;

namespace NoRest.Controllers
{
    public class CreateJobsController : Controller
    {
        private NoRestDBContext db = new NoRestDBContext();

        // GET: CreateJobs
        public ActionResult Index()
        {
            var createJobs = db.CreateJobs.Include(c => c.JobTypes).Include(c => c.Types);
            return View(createJobs.ToList());
        }

        // GET: CreateJobs/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CreateJob createJob = db.CreateJobs.Find(id);
            if (createJob == null)
            {
                return HttpNotFound();
            }
            return View(createJob);
        }

        // GET: CreateJobs/Create
        public ActionResult Create()
        {
            ViewBag.JOBTypeID = new SelectList(db.JobTypess, "JOBTypeID", "JobType");
            ViewBag.TypeID = new SelectList(db.Typess, "TypeID", "Typename");
            return View();
        }

        // POST: CreateJobs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "JobID,TypeID,UserID,RequiredSkill,Job_Description,Pay_scale,JOBTypeID")] CreateJob createJob)
        {
            if (ModelState.IsValid)
            {
                db.CreateJobs.Add(createJob);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.JOBTypeID = new SelectList(db.JobTypess, "JOBTypeID", "JobType", createJob.JOBTypeID);
            ViewBag.TypeID = new SelectList(db.Typess, "TypeID", "Typename", createJob.TypeID);
            return View(createJob);
        }

        // GET: CreateJobs/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CreateJob createJob = db.CreateJobs.Find(id);
            if (createJob == null)
            {
                return HttpNotFound();
            }
            ViewBag.JOBTypeID = new SelectList(db.JobTypess, "JOBTypeID", "JobType", createJob.JOBTypeID);
            ViewBag.TypeID = new SelectList(db.Typess, "TypeID", "Typename", createJob.TypeID);
            return View(createJob);
        }

        // POST: CreateJobs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "JobID,TypeID,UserID,RequiredSkill,Job_Description,Pay_scale,JOBTypeID")] CreateJob createJob)
        {
            if (ModelState.IsValid)
            {
                db.Entry(createJob).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.JOBTypeID = new SelectList(db.JobTypess, "JOBTypeID", "JobType", createJob.JOBTypeID);
            ViewBag.TypeID = new SelectList(db.Typess, "TypeID", "Typename", createJob.TypeID);
            return View(createJob);
        }

        // GET: CreateJobs/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CreateJob createJob = db.CreateJobs.Find(id);
            if (createJob == null)
            {
                return HttpNotFound();
            }
            return View(createJob);
        }

        // POST: CreateJobs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            CreateJob createJob = db.CreateJobs.Find(id);
            db.CreateJobs.Remove(createJob);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
