﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using NoRest;

namespace NoRest.Controllers
{
    public class RequestJobsController : Controller
    {
        private NoRestDBContext db = new NoRestDBContext();

        // GET: RequestJobs
        public ActionResult Index()
        {
            var requestJobs = db.RequestJobs.Include(r => r.CreateJob);
            return View(requestJobs.ToList());
        }

        // GET: RequestJobs/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            RequestJob requestJob = db.RequestJobs.Find(id);
            if (requestJob == null)
            {
                return HttpNotFound();
            }
            return View(requestJob);
        }

        // GET: RequestJobs/Create
        public ActionResult Create()
        {
            ViewBag.JobID = new SelectList(db.CreateJobs, "JobID", "RequiredSkill");
            return View();
        }

        // POST: RequestJobs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ReqID,JobID,UserID,ReqStatus")] RequestJob requestJob)
        {
            if (ModelState.IsValid)
            {
                db.RequestJobs.Add(requestJob);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.JobID = new SelectList(db.CreateJobs, "JobID", "RequiredSkill", requestJob.JobID);
            return View(requestJob);
        }

        // GET: RequestJobs/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            RequestJob requestJob = db.RequestJobs.Find(id);
            if (requestJob == null)
            {
                return HttpNotFound();
            }
            ViewBag.JobID = new SelectList(db.CreateJobs, "JobID", "RequiredSkill", requestJob.JobID);
            return View(requestJob);
        }

        // POST: RequestJobs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ReqID,JobID,UserID,ReqStatus")] RequestJob requestJob)
        {
            if (ModelState.IsValid)
            {
                db.Entry(requestJob).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.JobID = new SelectList(db.CreateJobs, "JobID", "RequiredSkill", requestJob.JobID);
            return View(requestJob);
        }

        // GET: RequestJobs/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            RequestJob requestJob = db.RequestJobs.Find(id);
            if (requestJob == null)
            {
                return HttpNotFound();
            }
            return View(requestJob);
        }

        // POST: RequestJobs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            RequestJob requestJob = db.RequestJobs.Find(id);
            db.RequestJobs.Remove(requestJob);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
