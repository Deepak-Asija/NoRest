﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using NoRest;

namespace NoRest.Controllers
{
    public class UserDetailsController : Controller
    {
        private NoRestDBContext db = new NoRestDBContext();
        // GET: UserDetails
        public ActionResult Index()
        {
            var userDetails = db.UserDetails.Include(u => u.Types);
            return View(userDetails.ToList());
        }
        [HttpGet]
        public ActionResult SignOut()
        {
            return RedirectToAction("Login");
        }

        [HttpGet]
        public ActionResult Login()
        {

            return View();
        }


        public ActionResult BackToHome()
        {
            int id = Convert.ToInt32(Session["UserID"]);
            UserDetail user = db.UserDetails.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            return RedirectToAction("AfterLogin", user);
        }

        [HttpPost]
        public ActionResult Login(UserDetail userDetail)
        {

            UserDetail user = db.UserDetails.FirstOrDefault(e => e.Password == userDetail.Password && e.EmailID == userDetail.EmailID);
            if (userDetail.EmailID == "Admin@admin.com" && userDetail.Password == "admin@admin123")
            {
                Session["EmailID"] = "Admin@admin.com";
                Session["Password"] = "admin@admin123";
                Session.Timeout = 2;
                return RedirectToAction("Index");
            }
            else if (user != null && user.TypeID == 1)
            {
                Session["UserID"] = user.UserID.ToString();
                Session["TypeID"] = user.TypeID.ToString();
                Session["UserName"] = user.UserName.ToString();
                Session["EmailID"] = user.EmailID.ToString();
                Session["Password"] = user.Password.ToString();
                return RedirectToAction("AfterLogin");
            }
            else if (user != null && user.TypeID == 2)
            {
                Session["UserID"] = user.UserID.ToString();
                Session["UserName"] = user.UserName.ToString();
                Session["EmailID"] = user.EmailID.ToString();
                Session["Password"] = user.Password.ToString();
                return RedirectToAction("UserLogin");
            }
            else
            {
                ViewBag.Status = "Invalid User or Password";
                return View();
            }
        }


        [HttpGet]
        public ActionResult AfterLogin()
        {
            int id = Convert.ToInt32(Session["UserID"]);
            UserDetail userDetail = db.UserDetails.Find(id);
            if (userDetail == null)
            {
                return HttpNotFound();
            }
            return View(userDetail);
        }

        [HttpGet]
        public ActionResult UserLogin()
        {
            int id = Convert.ToInt32(Session["UserID"]);
            UserDetail userDetail = db.UserDetails.Find(id);
            if (userDetail == null)
            {
                return HttpNotFound();
            }
            return View(userDetail);
        }

        public ActionResult UserEdits(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserDetail userDetail = db.UserDetails.Find(id);
            if (userDetail == null)
            {
                return HttpNotFound();
            }
            ViewBag.TypeID = new SelectList(db.Typess, "TypeID", "Typename", userDetail.TypeID);
            return View(userDetail);
        }

        // POST: UserDetails/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UserEdits([Bind(Include = "UserID,UserName,TypeID,EmailID,Password,ContactNo")] UserDetail userDetail)
        {
            if (ModelState.IsValid)
            {
                db.Entry(userDetail).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("UserLogin", userDetail);
            }
            ViewBag.TypeID = new SelectList(db.Typess, "TypeID", "Typename", userDetail.TypeID);
            return View(userDetail);
        }



        public ActionResult SkillCreate()
        {

            int id = Convert.ToInt32(Session["UserID"]);
            ViewBag.UserID = new SelectList(db.UserDetails.Where(c => c.UserID == id).ToList(), "UserID", "UserName");
            return View();
        }

        // POST: Skills/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SkillCreate([Bind(Include = "SkillId,UserID,SkillName,Experience_years,Job_Nature")] Skill skill)
        {
            if (ModelState.IsValid)
            {
                db.Skills.Add(skill);
                db.SaveChanges();
                return RedirectToAction("SearchJob",skill);
            }

            return View(skill);
        }

        public ActionResult SearchJob(Skill skill)
        {
            CreateJob job = new CreateJob();
            int id = Convert.ToInt32(Session["UserID"]);
            string Rskill = skill.SkillName;
            var createJobs = db.CreateJobs.Include(c => c.JobTypes).Include(c => c.Types).Where(c => c.RequiredSkill == Rskill);
            Session["JobID"] = job.JobID;
            return View(createJobs.ToList());

        }

        [HttpGet]
        public ActionResult JobCreate()
        {
            int id = Convert.ToInt32(Session["UserID"]);
            ViewBag.JobID = new SelectList(db.CreateJobs, "JobID", "RequiredSkill");
            ViewBag.UserID = new SelectList(db.UserDetails.Where(c => c.UserID == id).ToList(), "UserID", "UserName");
            ViewBag.ReqStatus = "PENDING";
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult JobCreate([Bind(Include = "ReqID,JobID,UserID,ReqStatus")] RequestJob requestJob)
        {
            if (ModelState.IsValid)
            {
                requestJob.UserID = Convert.ToInt32(Session["UserID"]);
                requestJob.ReqStatus = "PENDING";
                db.RequestJobs.Add(requestJob);
                db.SaveChanges();
                return RedirectToAction("Applyjob");
            }

            ViewBag.JobID = new SelectList(db.CreateJobs, "JobID", "RequiredSkill", requestJob.JobID);
            return View(requestJob);
        }


        public ActionResult Applyjob()
        {
            int id = Convert.ToInt32(Session["UserID"]);
            var requestJobs = db.RequestJobs.Include(r => r.CreateJob).Where(r => r.UserID == id);
            return View(requestJobs.ToList());
        }


        public ActionResult UserEdit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserDetail userDetail = db.UserDetails.Find(id);
            if (userDetail == null)
            {
                return HttpNotFound();
            }
            ViewBag.TypeID = new SelectList(db.Typess, "TypeID", "Typename", userDetail.TypeID);
            return View(userDetail);
        }

        // POST: UserDetails/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UserEdit([Bind(Include = "UserID,UserName,TypeID,EmailID,Password,ContactNo")] UserDetail userDetail)
        {
            if (ModelState.IsValid)
            {
                db.Entry(userDetail).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("AfterLogin", userDetail);
            }
            ViewBag.TypeID = new SelectList(db.Typess, "TypeID", "Typename", userDetail.TypeID);
            return View(userDetail);
        }

        [HttpGet]
        public ActionResult QualificationDetail()
        {
            int id = 0;
            id = Convert.ToInt32(Session["UserID"]);
            Qualification quali = db.Qualifications.Find(id);

            //UserDetail userDetail = db.UserDetails.Find(id);

            if (quali == null)
            {
                return RedirectToAction("QualificationCreate");
            }


            ViewBag.UserID = new SelectList(db.UserDetails, "UserID", "UserName", quali.UserID);
            return View(quali);

        }

        // GET: UserDetails/Create
        public ActionResult QualificationCreate()
        {

            int id = Convert.ToInt32(Session["UserID"]);
            ViewBag.UserID = new SelectList(db.UserDetails.Where(c => c.UserID == id).ToList(), "UserID", "UserName");
            return View();
        }

        // POST: UserDetails/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult QualificationCreate([Bind(Include = "QualID,UserID,Qualified,PassingYear")] Qualification qualification)
        {
            if (ModelState.IsValid)
            {
                qualification.UserID = Convert.ToInt32(Session["UserID"]);
                db.Qualifications.Add(qualification);
                db.SaveChanges();
                return RedirectToAction("QualificationDetail");
            }

            ViewBag.UserID = new SelectList(db.UserDetails, "UserID", "UserName", qualification.UserID);
            return View(qualification);
        }


        public ActionResult QualificationEdit(int? id)
        {
            id = Convert.ToInt32(Session["UserID"]);
            Qualification qualification = db.Qualifications.Find(id);
            if (qualification == null)
            {
                return HttpNotFound();
            }
            ViewBag.UserID = new SelectList(db.UserDetails, "UserID", "UserName", qualification.UserID);
            return View(qualification);
        }

        // POST: UserDetails/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult QualificationEdit([Bind(Include = "QualID,UserID,Qualified,PassingYear")] Qualification qualification)
        {
            if (ModelState.IsValid)
            {
                qualification.UserID = Convert.ToInt32(Session["UserID"]);
                db.Entry(qualification).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("QualificationDetail", qualification);
            }
            ViewBag.UserID = new SelectList(db.UserDetails, "UserID", "UserName", qualification.UserID);
            return View(qualification);
        }

        [HttpGet]
        public ActionResult QualificationAddress()
        {
            int id = 0;
            id = Convert.ToInt32(Session["UserID"]);
            Registration registration = db.Registrations.Find(id);

            if (registration == null)
            {
                return RedirectToAction("AddressCreate");
            }


            ViewBag.UserID = new SelectList(db.UserDetails, "UserID", "UserName", registration.UserID);
            return View(registration);
        }

        // GET: UserDetails/Create
        public ActionResult AddressCreate()
        {

            int id = Convert.ToInt32(Session["UserID"]);
            ViewBag.UserID = new SelectList(db.UserDetails.Where(c => c.UserID == id).ToList(), "UserID", "UserName");
            return View();
        }

        // POST: UserDetails/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddressCreate([Bind(Include = "RegID,UserID,Address,Pincode,DOB")] Registration registration)
        {
            if (ModelState.IsValid)
            {
                registration.UserID = Convert.ToInt32(Session["UserID"]);
                db.Registrations.Add(registration);
                db.SaveChanges();
                return RedirectToAction("QualificationAddress");
            }

            ViewBag.UserID = new SelectList(db.UserDetails, "UserID", "UserName", registration.UserID);
            return View(registration);
        }

        public ActionResult JobProvider()
        {
            int id = Convert.ToInt32(Session["UserID"]);
            CreateJob createJob = new CreateJob();
            ViewBag.TypeID = new SelectList(db.Typess.Where(c => c.TypeID == 1).ToList(), "TypeID", "Typename");
            ViewBag.UserID = new SelectList(db.UserDetails.Where(c => c.UserID == id).ToList(), "UserID", "UserName");
            ViewBag.JOBTypeID = new SelectList(db.JobTypess, "JOBTypeID", "JobType", createJob.JOBTypeID);
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult JobProvider([Bind(Include = "JobID,TypeID,RequiredSkill,Job_Description,Pay_scale,JOBTypeID")] CreateJob createJob)
        {
            if (ModelState.IsValid)
            {
                createJob.TypeID = 1;
                createJob.UserID = Convert.ToInt32(Session["UserID"]);
                db.CreateJobs.Add(createJob);
                db.SaveChanges();
                return RedirectToAction("jobdetail");
            }

            ViewBag.TypeID = new SelectList(db.Typess, "TypeID", "Typename", createJob.TypeID);
            return View(createJob);
        }


        [HttpGet]
        public ActionResult jobdetail()
        {
            int id = Convert.ToInt32(Session["UserID"]);
            var createJobs = db.CreateJobs.Include(c => c.JobTypes).Include(c => c.Types).Where(c => c.UserID == id);
            return View(createJobs.ToList());
        }



        // GET: UserDetails/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserDetail userDetail = db.UserDetails.Find(id);
            if (userDetail == null)
            {
                return HttpNotFound();
            }
            return View(userDetail);
        }

        // GET: UserDetails/Create
        public ActionResult Create()
        {
            ViewBag.TypeID = new SelectList(db.Typess, "TypeID", "Typename");
            return View();
        }

        // POST: UserDetails/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "UserID,UserName,TypeID,EmailID,Password,ContactNo")] UserDetail userDetail)
        {
            if (ModelState.IsValid)
            {
                db.UserDetails.Add(userDetail);
                db.SaveChanges();
                return RedirectToAction("Login");
            }

            ViewBag.TypeID = new SelectList(db.Typess, "TypeID", "Typename", userDetail.TypeID);
            return View(userDetail);
        }

        // GET: UserDetails/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserDetail userDetail = db.UserDetails.Find(id);
            if (userDetail == null)
            {
                return HttpNotFound();
            }
            ViewBag.TypeID = new SelectList(db.Typess, "TypeID", "Typename", userDetail.TypeID);
            return View(userDetail);
        }

        // POST: UserDetails/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "UserID,UserName,TypeID,EmailID,Password,ContactNo")] UserDetail userDetail)
        {
            if (ModelState.IsValid)
            {
                db.Entry(userDetail).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.TypeID = new SelectList(db.Typess, "TypeID", "Typename", userDetail.TypeID);
            return View(userDetail);
        }

        // GET: UserDetails/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserDetail userDetail = db.UserDetails.Find(id);
            if (userDetail == null)
            {
                return HttpNotFound();
            }
            return View(userDetail);
        }

        // POST: UserDetails/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            UserDetail userDetail = db.UserDetails.Find(id);
            db.UserDetails.Remove(userDetail);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        public ActionResult DeleteJobApply(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            RequestJob requestJob = db.RequestJobs.Find(id);
            if (requestJob == null)
            {
                return HttpNotFound();
            }
            return View(requestJob);
        }

        [HttpPost, ActionName("DeleteJobApply")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteJobApply(int id)
        {
      
            RequestJob requestJob = db.RequestJobs.Find(id);
            db.RequestJobs.Remove(requestJob);
            db.SaveChanges();
            return RedirectToAction("Applyjob");
        }














        [HttpGet]
        public ActionResult UserQualificationDetail(int? id)
        {

            id = Convert.ToInt32(Session["UserID"]);
            Qualification quali = db.Qualifications.Find(id);

            //UserDetail userDetail = db.UserDetails.Find(id);

            if (quali == null)
            {
                return RedirectToAction("UserQualificationCreate");
            }


            ViewBag.UserID = new SelectList(db.UserDetails, "UserID", "UserName", quali.UserID);
            return View(quali);

        }

        // GET: UserDetails/Create
        public ActionResult UserQualificationCreate()
        {

            int id = Convert.ToInt32(Session["UserID"]);
            ViewBag.UserID = new SelectList(db.UserDetails.Where(c => c.UserID == id).ToList(), "UserID", "UserName");
            return View();
        }

        // POST: UserDetails/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UserQualificationCreate([Bind(Include = "QualID,UserID,Qualified,PassingYear")] Qualification qualification)
        {
            if (ModelState.IsValid)
            {
                qualification.UserID = Convert.ToInt32(Session["UserID"]);
                db.Qualifications.Add(qualification);
                db.SaveChanges();
                return RedirectToAction("UserQualificationDetail");
            }

            ViewBag.UserID = new SelectList(db.UserDetails, "UserID", "UserName", qualification.UserID);
            return View(qualification);
        }


        public ActionResult UserQualificationEdit(int? id)
        {
            id = Convert.ToInt32(Session["UserID"]);
            Qualification qualification = db.Qualifications.Find(id);
            if (qualification == null)
            {
                return HttpNotFound();
            }
            ViewBag.UserID = new SelectList(db.UserDetails, "UserID", "UserName", qualification.UserID);
            return View(qualification);
        }

        // POST: UserDetails/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UserQualificationEdit([Bind(Include = "QualID,UserID,Qualified,PassingYear")] Qualification qualification)
        {
            if (ModelState.IsValid)
            {
                qualification.UserID = Convert.ToInt32(Session["UserID"]);
                db.Entry(qualification).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("QualificationDetail", qualification);
            }
            ViewBag.UserID = new SelectList(db.UserDetails, "UserID", "UserName", qualification.UserID);
            return View(qualification);
        }

        [HttpGet]
        public ActionResult UserQualificationAddress()
        {
            int id = 0;
            id = Convert.ToInt32(Session["UserID"]);
            Registration registration = db.Registrations.Find(id);

            if (registration == null)
            {
                return RedirectToAction("UserAddressCreate");
            }


            ViewBag.UserID = new SelectList(db.UserDetails, "UserID", "UserName", registration.UserID);
            return View(registration);
        }

        // GET: UserDetails/Create
        public ActionResult UserAddressCreate()
        {

            int id = Convert.ToInt32(Session["UserID"]);
            ViewBag.UserID = new SelectList(db.UserDetails.Where(c => c.UserID == id).ToList(), "UserID", "UserName");
            return View();
        }

        // POST: UserDetails/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UserAddressCreate([Bind(Include = "RegID,UserID,Address,Pincode,DOB")] Registration registration)
        {
            if (ModelState.IsValid)
            {
                registration.UserID = Convert.ToInt32(Session["UserID"]);
                db.Registrations.Add(registration);
                db.SaveChanges();
                return RedirectToAction("UserQualificationAddress");
            }

            ViewBag.UserID = new SelectList(db.UserDetails, "UserID", "UserName", registration.UserID);
            return View(registration);
        }


        public ActionResult UserAddressEdit(int? id)
        {
            id = Convert.ToInt32(Session["UserID"]);
            Registration registration= db.Registrations.Find(id);
            if (registration == null)
            {
                return HttpNotFound();
            }
            ViewBag.UserID = new SelectList(db.UserDetails, "UserID", "UserName", registration.UserID);
            return View(registration);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UserAddressEdit([Bind(Include = "RegID,UserID,Address,Pincode,DOB")] Registration registration)
        {
            if (ModelState.IsValid)
            {
                registration.UserID = Convert.ToInt32(Session["UserID"]);
                db.Entry(registration).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("QualificationAddress", registration);
            }
            ViewBag.UserID = new SelectList(db.UserDetails, "UserID", "UserName", registration.UserID);
            return View(registration);
        }

        public ActionResult AddressEdit(int? id)
        {
            id = Convert.ToInt32(Session["UserID"]);
            Registration registration = db.Registrations.Find(id);
            if (registration == null)
            {
                return HttpNotFound();
            }
            ViewBag.UserID = new SelectList(db.UserDetails, "UserID", "UserName", registration.UserID);
            return View(registration);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddressEdit([Bind(Include = "RegID,UserID,Address,Pincode,DOB")] Registration registration)
        {
            if (ModelState.IsValid)
            {
                registration.UserID = Convert.ToInt32(Session["UserID"]);
                db.Entry(registration).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("QualificationAddress", registration);
            }
            ViewBag.UserID = new SelectList(db.UserDetails, "UserID", "UserName", registration.UserID);
            return View(registration);
        }














        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
