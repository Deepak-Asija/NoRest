﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NoRest
{
    public class CreateJob
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]

        public int JobID { get; set; }
        [ForeignKey("Types")]
        public int TypeID { get; set; }
        [ForeignKey("UserDetails")]
        public int UserID { get; set; }
        public string RequiredSkill { get; set; }
        public string Job_Description { get; set; }

        public string  Pay_scale { get; set; }
        [ForeignKey("JobTypes")]
        public int JOBTypeID { get; set; }
        public virtual Types Types { get; set; }
        public virtual JobTypes JobTypes { get; set; }
        public virtual ICollection<UserDetail> UserDetails { get; set; }

    }
}