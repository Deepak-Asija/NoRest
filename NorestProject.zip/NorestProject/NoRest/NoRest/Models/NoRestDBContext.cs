﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Data.SqlClient;

namespace NoRest
{
    public class NoRestDBContext : DbContext
    {
        public NoRestDBContext(): base("name=HCLPracticeConnectionString")
        {

        }
        public virtual DbSet<Types> Typess { get; set; }
        public virtual DbSet<JobTypes> JobTypess { get; set; }
        public virtual DbSet<UserDetail> UserDetails { get; set; }
        public virtual DbSet<Registration> Registrations { get; set; }
        public virtual DbSet<Qualification> Qualifications { get; set; }
        public virtual DbSet<Skill> Skills { get; set; }
        public virtual DbSet<CreateJob> CreateJobs { get; set; }
        public virtual DbSet<RequestJob> RequestJobs { get; set; }



    }
}
