﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace NoRest
{
    public class Skill
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int SkillId { get; set; }
        [ForeignKey("UserDetail")]
        public int UserID { get; set; }
        public string SkillName { get; set; }
        public int Experience_years { get; set; }
        public string Job_Nature { get; set; }
        public virtual ICollection<UserDetail> UserDetail { get; set; }

    }
}