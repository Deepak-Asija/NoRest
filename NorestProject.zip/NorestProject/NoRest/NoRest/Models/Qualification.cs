﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace NoRest
{
    public class Qualification
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int QualID { get; set; }
        [ForeignKey("UserDetail")]
        public int UserID { get; set; }

        public string Qualified { get; set; }

        public int PassingYear { get; set; }

        public virtual UserDetail UserDetail { get; set; }
    }
}