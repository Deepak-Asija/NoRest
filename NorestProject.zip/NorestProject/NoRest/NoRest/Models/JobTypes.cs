﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NoRest
{
    public class JobTypes
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int JOBTypeID { get; set; }

        public string JobType { get; set; }
    }
}