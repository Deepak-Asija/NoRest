﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace NoRest
{
    public class RequestJob
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ReqID { get; set; }
        [ForeignKey("CreateJob")]
        public int JobID { get; set; }
        [ForeignKey("UserDetail")]
        public int UserID { get; set; }
        public string ReqStatus { get; set; }
        public virtual CreateJob CreateJob { get; set; }
        public virtual ICollection<UserDetail> UserDetail { get; set; }

    }
}