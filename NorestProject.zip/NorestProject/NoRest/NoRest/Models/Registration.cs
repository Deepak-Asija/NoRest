﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace NoRest
{
    public class Registration
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int RegID { get; set; }
        [ForeignKey("UserDetail")]
        public int UserID { get; set; }

        public string Address { get; set; }

        public int Pincode { get; set; }
        [DataType(DataType.Date)]
        [DisplayName("Date of Birth")]
        public DateTime DOB { get; set; }

        public virtual UserDetail UserDetail { get; set; }
    }
}