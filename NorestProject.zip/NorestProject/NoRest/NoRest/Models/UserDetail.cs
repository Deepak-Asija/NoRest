﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace NoRest
{
    public class UserDetail
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int UserID { get; set; }
        [Required(ErrorMessage ="please enter user name in upper case")]
        [DisplayName("Name : Hint ABCDE ABCDEFGH")]
        [RegularExpression("^[A-Z]{4,8} [A-Z]{4,8}$")]
        public string UserName { get; set; }
        [ForeignKey("Types")]
        public int TypeID { get; set; }
        [Required(ErrorMessage = "please enter EmailID eg. xyz@abc.com")]
        [DisplayName("Email")]
        public string EmailID { get; set; }
        [Required(ErrorMessage = "please enter Password")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        [Required(ErrorMessage = "ContactNo is mandatory")]
        public double ContactNo { get; set; }
        public virtual Types Types { get; set; }
    }
}
