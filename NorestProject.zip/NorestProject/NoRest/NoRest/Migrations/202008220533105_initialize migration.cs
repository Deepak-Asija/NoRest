﻿namespace NoRest.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class initializemigration : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.CreateJobs", "RequiredSkill", c => c.String());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.CreateJobs", "RequiredSkill", c => c.Int(nullable: false));
        }
    }
}
