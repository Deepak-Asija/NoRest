﻿namespace NoRest.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class initializemigration : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.CreateJobs",
                c => new
                    {
                        JobID = c.Int(nullable: false, identity: true),
                        TypeID = c.Int(nullable: false),
                        UserID = c.Int(nullable: false),
                        RequiredSkill = c.String(),
                        Job_Description = c.String(),
                        Pay_scale = c.String(),
                        JOBTypeID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.JobID)
                .ForeignKey("dbo.JobTypes", t => t.JOBTypeID, cascadeDelete: true)
                .ForeignKey("dbo.Types", t => t.TypeID, cascadeDelete: true)
                .Index(t => t.TypeID)
                .Index(t => t.JOBTypeID);
            
            CreateTable(
                "dbo.JobTypes",
                c => new
                    {
                        JOBTypeID = c.Int(nullable: false, identity: true),
                        JobType = c.String(),
                    })
                .PrimaryKey(t => t.JOBTypeID);
            
            CreateTable(
                "dbo.Types",
                c => new
                    {
                        TypeID = c.Int(nullable: false, identity: true),
                        Typename = c.String(),
                    })
                .PrimaryKey(t => t.TypeID);
            
            CreateTable(
                "dbo.UserDetails",
                c => new
                    {
                        UserID = c.Int(nullable: false, identity: true),
                        UserName = c.String(nullable: false),
                        TypeID = c.Int(nullable: false),
                        EmailID = c.String(nullable: false),
                        Password = c.String(nullable: false),
                        ContactNo = c.Double(nullable: false),
                        CreateJob_JobID = c.Int(),
                        RequestJob_ReqID = c.Int(),
                        Skill_SkillId = c.Int(),
                    })
                .PrimaryKey(t => t.UserID)
                .ForeignKey("dbo.Types", t => t.TypeID, cascadeDelete: true)
                .ForeignKey("dbo.CreateJobs", t => t.CreateJob_JobID)
                .ForeignKey("dbo.RequestJobs", t => t.RequestJob_ReqID)
                .ForeignKey("dbo.Skills", t => t.Skill_SkillId)
                .Index(t => t.TypeID)
                .Index(t => t.CreateJob_JobID)
                .Index(t => t.RequestJob_ReqID)
                .Index(t => t.Skill_SkillId);
            
            CreateTable(
                "dbo.Qualifications",
                c => new
                    {
                        QualID = c.Int(nullable: false, identity: true),
                        UserID = c.Int(nullable: false),
                        Qualified = c.String(),
                        PassingYear = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.QualID)
                .ForeignKey("dbo.UserDetails", t => t.UserID, cascadeDelete: true)
                .Index(t => t.UserID);
            
            CreateTable(
                "dbo.Registrations",
                c => new
                    {
                        RegID = c.Int(nullable: false, identity: true),
                        UserID = c.Int(nullable: false),
                        Address = c.String(),
                        Pincode = c.Int(nullable: false),
                        DOB = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.RegID)
                .ForeignKey("dbo.UserDetails", t => t.UserID, cascadeDelete: true)
                .Index(t => t.UserID);
            
            CreateTable(
                "dbo.RequestJobs",
                c => new
                    {
                        ReqID = c.Int(nullable: false, identity: true),
                        JobID = c.Int(nullable: false),
                        UserID = c.Int(nullable: false),
                        ReqStatus = c.String(),
                    })
                .PrimaryKey(t => t.ReqID)
                .ForeignKey("dbo.CreateJobs", t => t.JobID, cascadeDelete: true)
                .Index(t => t.JobID);
            
            CreateTable(
                "dbo.Skills",
                c => new
                    {
                        SkillId = c.Int(nullable: false, identity: true),
                        UserID = c.Int(nullable: false),
                        SkillName = c.String(),
                        Experience_years = c.Int(nullable: false),
                        Job_Nature = c.String(),
                    })
                .PrimaryKey(t => t.SkillId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.UserDetails", "Skill_SkillId", "dbo.Skills");
            DropForeignKey("dbo.UserDetails", "RequestJob_ReqID", "dbo.RequestJobs");
            DropForeignKey("dbo.RequestJobs", "JobID", "dbo.CreateJobs");
            DropForeignKey("dbo.Registrations", "UserID", "dbo.UserDetails");
            DropForeignKey("dbo.Qualifications", "UserID", "dbo.UserDetails");
            DropForeignKey("dbo.UserDetails", "CreateJob_JobID", "dbo.CreateJobs");
            DropForeignKey("dbo.UserDetails", "TypeID", "dbo.Types");
            DropForeignKey("dbo.CreateJobs", "TypeID", "dbo.Types");
            DropForeignKey("dbo.CreateJobs", "JOBTypeID", "dbo.JobTypes");
            DropIndex("dbo.RequestJobs", new[] { "JobID" });
            DropIndex("dbo.Registrations", new[] { "UserID" });
            DropIndex("dbo.Qualifications", new[] { "UserID" });
            DropIndex("dbo.UserDetails", new[] { "Skill_SkillId" });
            DropIndex("dbo.UserDetails", new[] { "RequestJob_ReqID" });
            DropIndex("dbo.UserDetails", new[] { "CreateJob_JobID" });
            DropIndex("dbo.UserDetails", new[] { "TypeID" });
            DropIndex("dbo.CreateJobs", new[] { "JOBTypeID" });
            DropIndex("dbo.CreateJobs", new[] { "TypeID" });
            DropTable("dbo.Skills");
            DropTable("dbo.RequestJobs");
            DropTable("dbo.Registrations");
            DropTable("dbo.Qualifications");
            DropTable("dbo.UserDetails");
            DropTable("dbo.Types");
            DropTable("dbo.JobTypes");
            DropTable("dbo.CreateJobs");
        }
    }
}
